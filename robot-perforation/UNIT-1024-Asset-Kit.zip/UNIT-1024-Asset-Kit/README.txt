UNIT 1024 · BRAND ASSET KIT · v1.0.1
Tigre Studio · Henry Mauricio Ortega

UNOFFICIAL CONCEPT. Not affiliated with or endorsed by Agility Robotics.
No Agility logos, marks or proprietary type are included.

WHAT'S HERE
mark/        The unit mark as SVG. 32 x 32 grid, 1,024 positions, 992 holes.
             - paper, reverse: field only, for light / dark grounds
             - ink-tile, teal-tile: on the tile, for busy grounds and app icons
             - screen-working: chest display, status green chevron
             - simple-under-48px: solid chevron, use below 48 px / 12 mm
             - fleet-unit-####: the same rule seeded by other unit numbers
icons/       18 icons, 24 px grid, 2 px stroke, square caps, mitre joins.
             _sprite.svg holds all of them as <symbol id="i-name">.
tokens/      tokens.json (W3C design-token format) and tokens.css.
             Use the semantic roles (bg-*, fg-*, status-*), not raw hex.
guidelines/  Brand guidelines PDF, 19 pages.
print/       Base-plate decal, 120 x 40 mm trim, 3 mm bleed, crop marks.
             Outline text before print; proof against a physical swatch.

RULES THAT MATTER MOST
1. Keep 4 cells of clear space around the mark. Never rotate it or move the chevron.
2. Red means stop, yellow means caution, green means running. Never decoration.
3. Teal-500 never carries text on paper; use teal-800 for teal text.
4. Every status gets an icon and a word, not just a colour.
5. Every number is measured, or labelled as a placeholder.

LIVE VERSIONS
Case study:     https://tigrestudiodesign.github.io/robot-perforation/
Design system:  https://tigrestudiodesign.github.io/robot-perforation/system/
